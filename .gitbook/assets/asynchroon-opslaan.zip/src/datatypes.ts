export interface Student {
    name: string;
    uuid: string;
}