import { useState } from "react";
import { Student } from "../datatypes";
import { v4 as uuidv4 } from 'uuid';

export interface StudentFormProps {
    students: Student[];
    setStudents: (students: Student[]) => void;
}

async function storeStudent(student: Student) {
    try {
        const response = await fetch("http://localhost:3001/students/",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(student)
            });
        if (!response.ok) {
            alert('Wel een antwoord, maar niet het verwachte. De student is niet opgeslagen.');
        }
    }
    catch (error) {
        alert("Er is misschien iets misgelopen bij het opslaan van de student.")
    }
}

export function StudentForm(props: StudentFormProps) {

    const [studentName, setStudentName] = useState<string>('');

    return (
        <form onSubmit={(event) => {
            event.preventDefault();
            const uuid = uuidv4();
            const newStudent = {name: studentName, uuid: uuid};
            storeStudent(newStudent);
            props.setStudents([...props.students, newStudent]);
            setStudentName('');
        }}>
            <label htmlFor="name"></label>
            <input
            type="text"
            id="name"
            name="name"
            value={studentName}
            onChange={(e) => setStudentName(e.target.value)} />
            <input type="submit" value="student opslaan" />
        </form>
    )
}