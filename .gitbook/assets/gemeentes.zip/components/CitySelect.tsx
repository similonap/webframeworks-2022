import { useState } from 'react';
import Select from 'react-select';

const belgianCities: string[] = [
    "Antwerp",
    "Ghent",
    "Charleroi",
    "Liege",
    "Brussels",
    "Bruges",
    "Schaarbeek",
    "Anderlecht",
    "Namur",
    "Leuven",
    "Mons",
    "Sint-Jans-Molenbeek",
    "Mechelen",
    "Elsene",
    "Aalst",
    "Ukkel",
    "La Louviere",
    "Hasselt",
    "Kortrijk",
    "Sint-Niklaas",
    "Oostende",
    "Tournai",
    "Genk",
    "Seraing",
    "Roeselare",
    "Mouscron",
    "Verviers",
    "Vorst",
    "Jette",
    "Beveren",
    "Etterbeek",
    "Dendermonde",
    "Beringen",
    "Turnhout",
    "Vilvoorde",
    "Heist-op-den-Berg",
    "Dilbeek",
    "Lokeren",
    "Sint-Truiden"
]

interface CitySelectOption {
    value: string;
    label: string;
}

const selectOptions: CitySelectOption[] = belgianCities.map(s => {
    return { value: s.toLocaleLowerCase().substring(0, 10), label: s }
});

export function CitySelect() {

    const [selectedCity, setSelectedCity] = useState<CitySelectOption | null>(null);

    return (
        <>
            <Select
                options={selectOptions}
                onChange={e => setSelectedCity(e)} />
            {selectedCity ?
                <p>Je selecteerde {selectedCity.label}</p> :
                <p>Geen stad geselecteerd.</p>}
        </>
    )
}