import './App.css';
import { CitySelect } from './components/CitySelect';

function App() {
  return (
    <div className="App">
      <CitySelect />
    </div>
  );
}

export default App;
