import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import { Student } from './datatypes';
import { StudentForm } from './components/StudentForm';

function App() {

  const [students, setStudents] = useState<Student[]>([]);

  return (
    <div className="App">
      <h1>Studenten</h1>
      <h2>Een student toevoegen</h2>
      <StudentForm students={students} setStudents={setStudents} />
      <h2>Reeds geregistreerde studenten</h2>
      <table>
        <thead>
          <tr>
            <th>Naam</th>
            <th>ID</th>
          </tr>
        </thead>
        <tbody>{students.map(s => {
          return (
          <tr>
            <td>{s.name}</td>
            <td>{s.uuid}</td>
          </tr>
          );
        })}</tbody>
      </table>
    </div>
  );
}

export default App;
